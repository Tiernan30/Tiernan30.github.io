# SENG 513 W17 Assignment 2
Skeleton code.

Put all your code into code.js.
